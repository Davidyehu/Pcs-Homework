package com.company;

public enum Type {

        Deposit,
        Withdrawal,
        Interest,
        Fee
}
