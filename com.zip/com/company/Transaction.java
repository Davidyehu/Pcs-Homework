package com.company;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Transaction {
    private String date;
    private Type type;
    private double amount;

    public Type getType() {
        return type;
    }

    public Transaction(Type type, double amount) {
        this.type = type;
        this.amount = amount;
        this.date = new SimpleDateFormat("MMM/dd/yyyy").format(Calendar.getInstance().getTimeInMillis());
    }

    public void print() {
        System.out.printf("Transaction, Type: %s, Amount: %.2f, Date: %s. \r\n", type, amount, date);
    }



}
