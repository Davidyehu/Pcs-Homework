package com.company;

public class MoneyMarketAccount extends InterestBearingAccount {

    public MoneyMarketAccount() {
        System.out.println("Congrats on opening up a new Money Market account!!");
    }

    private static int withdrawals = 2;

    @Override
    public void deposit(double amount, Type type) {
        super.deposit(amount, type);
        System.out.println("for your " + getClass().getName().substring(12) + ".");
    }

    @Override
    public void withdraw(double amount, Type type) {
        super.withdraw(amount, type);
        withdrawals--;
        System.out.println("for your " + getClass().getName().substring(12) + ".");
    }



    @Override
    public void endOfMonth() {
        double fee = 2.00 - (getBalance() * .005); //the rich get richer......
        double totalFee = 0;
        for (int i = withdrawals; i <= 0; i++) {
            totalFee += fee;
        }
        if (totalFee > 0) {
            System.out.print("Fees: ");
            withdraw(totalFee, Type.Fee);
        }
        super.endOfMonth();
    }
}
