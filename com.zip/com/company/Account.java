package com.company;

import java.util.ArrayList;

public abstract class Account {

        private double balance;
        private ArrayList<Transaction> transactions = new ArrayList<>();

    public double getBalance() {
            return balance;
        }

        public void deposit(double amount, Type type){
            balance += amount;
            this.transactions.add(new Transaction(type, amount));
            System.out.printf("A deposit has been made for the amount of: %.2f, of Type: %s, ", amount, type);
        }

        public void withdraw(double amount, Type type){
            balance -= amount;
            this.transactions.add(new Transaction(type, amount));
            System.out.printf("A withdrawal has been made for the amount of: %.2f, of Type: %s, ", amount, type);
        }

        public void endOfMonth(){
            System.out.printf("Balance: %.2f \r\n", balance);
            System.out.println("Transactions:");
            printTransactions();
        }

        private void printTransactions() {
            for (Transaction transaction: transactions) {
                transaction.print();
            }
        }
}
