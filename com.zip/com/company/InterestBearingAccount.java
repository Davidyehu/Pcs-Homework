package com.company;


public abstract class InterestBearingAccount extends Account {

    public void endOfMonth(){
        super.endOfMonth();
        if (getBalance() > 0) {
            deposit(getBalance() * .02, Type.Interest);
        }
        System.out.printf("Balance after interest: %.2f \r\n", getBalance());
    }
}
