package com.company;


public class Bank {
    public static void main(String[] args) {
        Account[] accounts = {
                new CheckingAccount(),
                new SavingsAccount(),
                new MoneyMarketAccount()
        };
        accounts[0].deposit(50.39, Type.Deposit);
        accounts[0].withdraw(33.39, Type.Withdrawal);
        accounts[0].endOfMonth();
        accounts[1].deposit(55.64, Type.Deposit);
        accounts[1].withdraw(27.64, Type.Withdrawal);
        accounts[1].endOfMonth();
        accounts[2].deposit(22.92, Type.Deposit);
        accounts[2].withdraw(27.92, Type.Withdrawal);
        accounts[2].endOfMonth();
    }

}
