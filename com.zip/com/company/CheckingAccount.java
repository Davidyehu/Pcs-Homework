package com.company;

public class CheckingAccount extends Account{

    private final double minimumBalance = 250.00;

    public CheckingAccount() {
        System.out.println("Congrats on your new Checking account, no fees no limits!!");
        deposit(minimumBalance, Type.Deposit);
    }

    @Override
    public void deposit(double amount, Type type) {
        super.deposit(amount, type);
        System.out.println("for your " + getClass().getName().substring(12) + ".");
    }

    @Override
    public void withdraw(double amount, Type type) {
        super.withdraw(amount, type);
        System.out.println("for your " + getClass().getName().substring(12) + ".");
    }
}
