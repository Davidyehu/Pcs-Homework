package com.company;

public class SavingsAccount extends InterestBearingAccount {

    private final double minimumBalance = 250.00;

    public SavingsAccount() {
        System.out.println("Congrats on opening up a new Savings account!!");
        deposit(minimumBalance, Type.Deposit);
    }

    @Override
    public void deposit(double amount, Type type) {
        super.deposit(amount, type);
        System.out.println("for your " + getClass().getName().substring(12) + ".");
    }

    @Override
    public void withdraw(double amount, Type type) {
        super.withdraw(amount + 5.00, type);
        System.out.println("for your " + getClass().getName().substring(12) + ".");
    }

}
