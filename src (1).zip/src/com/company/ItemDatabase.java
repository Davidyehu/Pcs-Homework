package com.company;

//public class ItemDatabase extends Item{
//    private static final ItemDatabase itemDatabase = new ItemDatabase();
//    Item[] items = new Item[1000];
//    int[] quantity = new int[items.length];
//
//    private ItemDatabase() {
//        insertItemInDatabase(new Item("Milk", "1 quart", 3.99, false), 25);
//        insertItemInDatabase(new Item("sugar", "Domino 1 kilo", 5.99, false), 2);
//        insertItemInDatabase(new Item("candy", "Paszkesz jelly beans", 2.99, true), 3);
//    }
//
//    public static ItemDatabase getInstance() {
//        return itemDatabase;
//    }
//
//    private void insertItemInDatabase(Item item, int quantity) {
//        for (int i = 0; i < items.length; i++) {
//            if (items[i] == null) {
//                items[i] = item;
//                this.quantity[i] = quantity;
//            }
//        }
//    }
//
//    public Item getItemById(int id){
//            return quantity[id]-- != 0 ? items[id] : null;
//    }
//
//}