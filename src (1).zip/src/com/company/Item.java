//package com.company;
//
//public class Item {
//    private String name;
//    private String description;
//    private double price;
//    private boolean isTaxable;
//
//    public Item() {
//    }
//
//    public Item(String name, String description, double price, boolean isTaxable) {
//        this.name = name;
//        this.description = description;
//        this.price = price;
//        this.isTaxable = isTaxable;
//    }
//
//    public void setFields(String name, String description, double price){
//        this.name = name;
//        this.description = description;
//        this.price = price;
//    }
//
//    public String getName() {
//        return name;
//    }
//
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public String getDescription() {
//        return description;
//    }
//
//    public void setDescription(String description) {
//        this.description = description;
//    }
//
//    public double getPrice() {
//        return price;
//    }
//
//    public void setPrice(double price) {
//        this.price = price;
//    }
//
//    public boolean getIsTaxable() {
//        return isTaxable;
//    }
//
//    public void setTaxable(boolean taxable) {
//        isTaxable = taxable;
//    }
//
//    public void print() {
//        System.out.printf("%s, %s, %s\n", name, description, price);
//    }
//}
